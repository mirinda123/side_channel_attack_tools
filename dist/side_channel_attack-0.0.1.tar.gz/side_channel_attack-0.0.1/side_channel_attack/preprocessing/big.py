import numpy as np
from tqdm import tqdm, trange
def big_moving_resamples(n,url,func):
    for j in trange(n):
        arr = np.load(url + r"arrPart{0}.npy".format(j))
        trace_result = func(arr, 5)
        np.save(url + r"result_arrPart{0}.npy".format(j), trace_result)