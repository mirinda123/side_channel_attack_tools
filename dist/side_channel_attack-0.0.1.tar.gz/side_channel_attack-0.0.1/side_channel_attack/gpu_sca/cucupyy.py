# 基本示例
# def online_mean(old_mean, new_x, N):
#     new_mean = old_mean + (new_x - old_mean) / (N + 1)
#     return new_mean
# def welford(old_var, old_mean, new_x, new_mean,N):
#     new_var = old_var + ((new_x - old_mean) * (new_x - new_mean) - old_var) / (N + 1)
#     return new_var

import numpy as np
from numpy import loadtxt
# 读入曲线
import cupy as cp
import time
from tqdm import tqdm, trange
# 求矩阵均值按列


# 求矩阵方差，按行



# 求一条data和trace每列的协方差
# 协方差好像只用到了均值
def cov_func(data,traces):
    if data.ndim == 1 and traces.ndim ==2:
        old_cov = np.zeros(traces.shape[1])
        # new_cov = np.zeros((traces.shape[0], traces.shape[1]))
        old_mean_data = np.zeros(len(data))
        # new_mean_data = np.zeros(len(data))
        old_mean_traces = np.zeros(traces.shape[1])
        # new_mean_traces = np.zeros((traces.shape[0], traces.shape[1]))
        count = 0
        for i in range(traces.shape[0]):
            # 初始化
            # 需要的均值
            new_mean_data = old_mean_data + (data[i] - old_mean_data) / (i + 1)
            new_mean_traces = old_mean_traces + (traces[i] - old_mean_traces) / (i + 1)
            # 均值的更新
            # 注意这里的i值
            # 协方差的计算
            new_cov = (old_cov*i + (data[i]-old_mean_data)*(traces[i]-new_mean_traces))/(count+1)
            count = count+1
            old_mean_data = new_mean_data
            old_mean_traces = new_mean_traces
            # 协方差更新
            old_cov = new_cov
            # print(old_cov[i+1],data[i+1]-old_mean_data[i])
        return old_cov
# 求一条data和trace每列的相关系数
def mean_func_gpu(traces):
    # n = 0
    if traces.ndim == 1:
        return cp.mean(traces)
    if traces.ndim == 2:
        old_mean = cp.zeros(traces.shape[1])
        for i in range(traces.shape[0]):
            # n = n+1
            new_mean = old_mean + (traces[i] - old_mean) / (i + 1)
            old_mean = new_mean
        return new_mean

def mean_func_gpu2(traces):
    # n = 0
    if traces.ndim == 1:
        return cp.mean(traces)
    if traces.ndim == 2:
        old_mean = cp.zeros(traces.shape[1])
        for i in range(traces.shape[0]):
            # n = n+1
            new_mean = cp.add(old_mean,cp.divide(cp.add(traces[i],-old_mean) , (cp.add(i,1))))
            old_mean = new_mean
        return new_mean


def var_func1(traces):
    if traces.ndim == 1:
        return np.var(traces)
    if traces.ndim == 2:
        old_var = np.zeros(traces.shape[1])
        old_mean = np.zeros(traces.shape[1])
        for i in range(traces.shape[0]):
            new_mean = old_mean + (traces[i] - old_mean) / (i + 1)
            new_var = old_var + ((traces[i] - old_mean) * (traces[i] - new_mean) - old_var) / (i + 1)
            old_mean = new_mean
            old_var = new_var
        return old_var

def var_func2(traces):
    if traces.ndim == 1:
        return cp.var(traces)
    if traces.ndim == 2:
        old_var = cp.zeros(traces.shape[1])
        old_mean = cp.zeros(traces.shape[1])
        for i in range(traces.shape[0]):
            new_mean = old_mean + (traces[i] - old_mean) / (i + 1)
            new_var = old_var + ((traces[i] - old_mean) * (traces[i] - new_mean) - old_var) / (i + 1)
            old_mean = new_mean
            old_var = new_var
        return old_var
# new_var[i+1] = old_var[i] + ((traces[i+1] - old_mean[i]) * (traces[i+1] - new_mean[i+1]) - old_var[i]) / (i + 1)
def var_func3(traces):
    if traces.ndim == 1:
        return cp.var(traces)
    if traces.ndim == 2:
        old_var = cp.zeros(traces.shape[1])
        old_mean = cp.zeros(traces.shape[1])
        count = 0
        for i in range(traces.shape[0]):
            new_mean = cp.add(old_mean, cp.divide((cp.subtract(traces[i], old_mean)), cp.add(count, 1)))
            # print(new_mean)
            # print(cp.add(count,1))
            new_var = cp.add(old_var,cp.divide(cp.subtract(cp.multiply(cp.subtract(traces[i],old_mean),cp.subtract(traces[i],new_mean)),old_var),cp.add(count,1)))
            # print(new_var)
            old_mean = new_mean
            old_var = new_var
            count = cp.add(count,1)
        return old_var

if __name__ == '__main__':
    import matplotlib.pyplot as plt

    # data = np.load(r"D:/side_channel_attack/attack_method/traces/SendData.npy")

    # numpy_trace = cp.load(r"D:/side_channel_attack/attack_method/1228traces/1228Traces3Traces4arrPart0.npy")

    numpy_trace = np.load(r"/attack_method/1228traces/1228Traces3Traces4arrPart0.npy")
    cupy_data = cp.load(r"/attack_method/1228traces/1228Traces3Traces4arrPart0.npy")
    numpy_trace = numpy_trace.astype(np.float32)
    # cupy_data = cupy_data.astype(cp.float32)


    start = time.time()
    print(np.var(numpy_trace, axis=0))
    end = time.time()
    print('np:')
    print(end - start)

    start = time.time()
    print(var_func1(numpy_trace))
    end = time.time()
    print('cPU:')
    print(end - start)

    start = time.time()
    print(var_func2(cupy_data))
    end = time.time()
    print('mixgpu:')
    print(end - start)

    start = time.time()
    print(var_func3(cupy_data))
    end = time.time()
    print('chungpu:')
    print(end - start)

    # start = time.time()
    # print(mean_func_gpu2(cupy_data))
    # end = time.time()
    # print('mix:')
    # print(end - start)

    # numpy_trace = np.load(r"E:/1224preprocessingOnlyToOneTrace1Trace2.npy")
    #
    # numpy_trace = numpy_trace.astype(np.float32)
    # start = time.time()
    # cupy_data = cp.asarray(numpy_trace)
    # end = time.time()
    # print('转换时间：')
    # print(end - start)
    #
    # start = time.time()
    # print(np.mean(numpy_trace,axis = 0))
    # end = time.time()
    # print('np:')
    # print(end - start)
    #
    # start = time.time()
    # print(mean_func_gpu(cupy_data))
    # end = time.time()
    # print('GPU:')
    # print(end-start)
    #
    #
    # start = time.time()
    # print(mean_func(numpy_trace))
    # end = time.time()
    # print('cpu:')
    # print(end - start)
    #
    #
    # start = time.time()
    # print(mean_func_gpu2(cupy_data))
    # end = time.time()
    # print('mix:')
    # print(end-start)
    # # plt.plot(abs(correlation_func(data, trace[0])))
    # plt.show()
    # start = time.time()
    # xiangliang = block_ttest(200, 30000)
    # end = time.time()
    # print('GPU:')
    # print(end-start)
    #
    # # plt.plot(xiangliang[0:29800])
    # # # arr = np.load(r"D:/side_channel_attack/attack_method/1227traces/arrPart0.npy")
    # # plt.show()
    #
    # start = time.time()
    # xiangliang = block_ttest2(200, 30000)
    # end = time.time()
    # print('CPU:')
    # print(end - start)
    #
    # start = time.time()
    # xiangliang = block_ttest2(200, 30000)
    # end = time.time()
    # print('CGPU:')
    # print(end - start)
    # np.save(r'D:/side_channel_attack/result/1230trace34.npy', xiangliang)
    # plt.plot(xiangliang[0:29800])
    # # arr = np.load(r"D:/side_channel_attack/attack_method/1227traces/arrPart0.npy")
    # plt.show()

