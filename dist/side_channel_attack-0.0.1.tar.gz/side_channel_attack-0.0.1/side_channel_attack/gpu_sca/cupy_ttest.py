
import numpy as np
from numpy import loadtxt
# 读入曲线
import cupy as cp
from tqdm import tqdm, trange
import time
def block_ttest(n,N):
    '''

    :param n: 因数据量大  分块数
    :param N: 每条曲线的采样点
    :return:奇偶曲线的ttest结果
    '''
    # N= 2
    count = 0
    old_var_even = cp.zeros(N)
    old_mean_even = cp.zeros(N)
    old_var_odd = cp.zeros(N)
    old_mean_odd = cp.zeros(N)
    oddcount = 0
    evencount = 0
    for j in trange(n):
        # arr = np.load(r"D:/side_channel_attack/attack_method/1228trace1trace2/fast_lowpassarrPart{0}.npy".format(j))
        # arr = np.load('D:/side_channel_attack/attack_method/traces/temp.npy')
        arr = cp.load(r"G:/1230trace3trace4/passarrPart{0}.npy".format(j))
        # arr = cp.asarray(arrn)
        for i in range(arr.shape[0]):
            if count % 2 == 0:
                new_mean = cp.add(old_mean_even , cp.divide((cp.subtract(arr[i], old_mean_even)), cp.add(evencount ,1)))
                new_var = cp.add(old_var_even,cp.divide(cp.subtract(cp.multiply(cp.subtract(arr[i] ,old_mean_even),cp.subtract(arr[i] , new_mean)) , old_var_even) , cp.add(evencount,1)))
                # new_var = old_var_even + ((arr[i] - old_mean_even) * (arr[i] - new_mean) - old_var_even) / (evencount + 1)
                # (arr[i] - old_mean_even) * (arr[i] - new_mean) = cp.multiply(cp.add(arr[i] ,- old_mean_even),cp.add(arr[i] ,- new_mean))
                # cp.multiply()
                old_mean_even = new_mean
                old_var_even = new_var
                evencount = cp.add(evencount,1)
                count = cp.add(count,1)
            else:
                new_mean = cp.add(old_mean_odd, cp.divide((cp.add(arr[i], -old_mean_odd)), cp.add(oddcount, 1)))
                new_var = cp.add(old_var_odd, cp.divide(
                    cp.add(cp.multiply(cp.add(arr[i], - old_mean_odd), cp.add(arr[i], - new_mean)), - old_var_odd),
                    cp.add(oddcount, 1)))
                # new_mean = old_mean_odd + (arr[i] - old_mean_odd) / (oddcount + 1)
                # new_var = old_var_odd + ((arr[i] - old_mean_odd) * (arr[i] - new_mean) - old_var_odd) / (oddcount + 1)
                old_mean_odd = new_mean
                old_var_odd = new_var
                oddcount = cp.add(oddcount,1)
                count = cp.add(count,1)

    temp1 = cp.subtract(old_mean_even,old_mean_odd)
    # temp1 = old_mean_odd - old_mean_even
    temp2 = cp.add(cp.divide(old_var_even,evencount),cp.divide(old_var_odd,oddcount))
    test_result = cp.divide(temp1 , cp.sqrt(temp2))
    return test_result

# cp.load()

def block_ttest2(n,N):
    '''

    :param n: 因数据量大  分块数
    :param Na: 序号奇数的曲线数量
    :param Nb: 序号偶数的曲线数量
    :param N: 每条曲线的采样点
    :return:奇偶曲线的ttest结果
    '''
    # N= 2
    count = 0
    old_var_even = np.zeros(N)
    old_mean_even = np.zeros(N)
    old_var_odd = np.zeros(N)
    old_mean_odd = np.zeros(N)
    oddcount = 0
    evencount = 0
    for j in trange(n):
        # arr = np.load(r"D:/side_channel_attack/attack_method/1228trace1trace2/fast_lowpassarrPart{0}.npy".format(j))
        # arr = np.load('D:/side_channel_attack/attack_method/traces/temp.npy')
        arr = np.load(r"G:/1230trace3trace4/passarrPart{0}.npy".format(j))

        for i in range(arr.shape[0]):
            if count % 2 == 0:
                new_mean = old_mean_even + (arr[i] - old_mean_even) / (evencount + 1)
                new_var = old_var_even + ((arr[i] - old_mean_even) * (arr[i] - new_mean) - old_var_even) / (evencount + 1)
                old_mean_even = new_mean
                old_var_even = new_var
                evencount += 1
                count = count + 1
            else:
                new_mean = old_mean_odd + (arr[i] - old_mean_odd) / (oddcount + 1)
                new_var = old_var_odd + ((arr[i] - old_mean_odd) * (arr[i] - new_mean) - old_var_odd) / (oddcount + 1)
                old_mean_odd = new_mean
                old_var_odd = new_var
                oddcount += 1
                count = count + 1

    temp1 = old_mean_even-old_mean_odd
    # temp1 = old_mean_odd - old_mean_even
    temp2 = (old_var_even/evencount)+(old_var_odd/oddcount)
    test_result = temp1 / np.sqrt(temp2)
    return test_result


def block_ttest3(n,N):
    '''

    :param n: 因数据量大  分块数
    :param Na: 序号奇数的曲线数量
    :param Nb: 序号偶数的曲线数量
    :param N: 每条曲线的采样点
    :return:奇偶曲线的ttest结果
    '''
    # N= 2
    count = 0
    old_var_even = cp.zeros(N)
    old_mean_even = cp.zeros(N)
    old_var_odd = cp.zeros(N)
    old_mean_odd = cp.zeros(N)
    oddcount = 0
    evencount = 0
    for j in trange(n):
        # arr = np.load(r"D:/side_channel_attack/attack_method/1228trace1trace2/fast_lowpassarrPart{0}.npy".format(j))
        # arr = np.load('D:/side_channel_attack/attack_method/traces/temp.npy')
        arr = np.load(r"G:/1230trace3trace4/passarrPart{0}.npy".format(j))

        for i in range(arr.shape[0]):
            if count % 2 == 0:
                new_mean = old_mean_even + (arr[i] - old_mean_even) / (evencount + 1)
                new_var = old_var_even + ((arr[i] - old_mean_even) * (arr[i] - new_mean) - old_var_even) / (evencount + 1)
                old_mean_even = new_mean
                old_var_even = new_var
                evencount += 1
                count = count + 1
            else:
                new_mean = old_mean_odd + (arr[i] - old_mean_odd) / (oddcount + 1)
                new_var = old_var_odd + ((arr[i] - old_mean_odd) * (arr[i] - new_mean) - old_var_odd) / (oddcount + 1)
                old_mean_odd = new_mean
                old_var_odd = new_var
                oddcount += 1
                count = count + 1

    temp1 = old_mean_even-old_mean_odd
    # temp1 = old_mean_odd - old_mean_even
    temp2 = (old_var_even/evencount)+(old_var_odd/oddcount)
    test_result = temp1 / cp.sqrt(temp2)
    return test_result
