import matplotlib.pyplot as plt
import numpy as np
import numpy.fft
from numpy.core.multiarray import normalize_axis_index
from numpy.core import asarray, zeros, swapaxes, conjugate, take, sqrt
from numba import cuda
from numba.extending import overload
from time import *
import cupy as cp
from cupy import fft


def fft_traces(traces,fft_traces):
    if traces.ndim == 1:
        fft_traces = cp.fft.fft(traces)
    if traces.ndim == 2:
        # t = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
        # gridStride = cuda.gridDim.x * cuda.blockDim.x
        # for j in range(t, traces.shape[0], gridStride):
        for i in range(traces.shape[0]):

            fft_traces[i] = cp.fft.fft(traces[i])
        return fft_traces

def gpu_fft_traces(traces,fft_traces):
    if traces.ndim == 1:
        fft_traces = np.fft.fft(traces)
    if traces.ndim == 2:
        # t = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
        # gridStride = cuda.gridDim.x * cuda.blockDim.x
        # for j in range(t, traces.shape[0], gridStride):
        for i in range(traces.shape[0]):

            fft_traces[i] = np.fft.fft(traces[i])
        return fft_traces
if __name__ == '__main__':
    trace12 = np.load(r"D:/side_channel_attack/preprocessing/mtraces/m0x01evenodd.npy")
    cupy_data = cp.asarray(trace12)
    # 使用默认流
    # trace12_device = cuda.to_device(trace12)
    # new_traces = cuda.device_array((trace12.shape[0], trace12.shape[1]), dtype=np.complex128)
    new_traces = cp.empty_like(cupy_data,dtype=cp.complex128)
    new_traces2 = np.empty_like(trace12, dtype=np.complex128)
    start = time()
    # fft_traces[1, 100](trace12_device[0], new_traces)
    fft_traces(cupy_data,new_traces)
    # gpu_result = new_traces.copy_to_host()
    # cuda.synchronize()
    print("gpu time" + str(time() - start))
    start = time()
    gpu_fft_traces(trace12,new_traces2)
    print("cpu time" + str(time() - start))
    # plt.plot(fft_traces(trace12))
    # plt.show()