from numba import cuda
import numpy as np
from matplotlib import pyplot as plt
from time import *
import math


@cuda.jit
def fast_lowpass(traces, a, new_traces):
    t = cuda.grid(1)
    if t >= traces.shape[0]:
        return
    for i in range(0, traces.shape[1]):
        if i == 0:
            new_traces[t][0] = traces[t][0]
        else:
            new_traces[t][i] = (a * traces[t][i - 1] + traces[t][i]) / (1 + a)


@cuda.jit
def fast_lowpass_wanggeyibu(traces, a, new_traces):
    t = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    gridStride = cuda.gridDim.x * cuda.blockDim.x
    for j in range(t, traces.shape[0], gridStride):
        for i in range(0, traces.shape[1]):
            if i == 0:
                new_traces[t][0] = traces[t][0]
            else:
                new_traces[t][i] = (a * traces[t][i - 1] + traces[t][i]) / (1 + a)


@cuda.jit
def fast_lowpass_duoliu(traces, a, new_traces):
    t = cuda.grid(1)
    if t >= traces.shape[0]:
        return
    for i in range(0, traces.shape[1]):
        if i == 0:
            new_traces[t][0] = traces[t][0]
        else:
            new_traces[t][i] = (a * traces[t][i - 1] + traces[t][i]) / (1 + a)

@cuda.jit
def fast_lowpass_sharememory(traces, a, new_traces):
    t = cuda.grid(1)
    if t >= traces.shape[0]:
        return
    for i in range(0, traces.shape[1]):
        if i == 0:
            new_traces[t][0] = traces[t][0]
        else:
            new_traces[t][i] = (a * traces[t][i - 1] + traces[t][i]) / (1 + a)
def fast_lowpass_cpu(traces, a):
    # if not isinstance(traces, np.ndarray):
    #     raise TypeError("'trace' should be a numpy ndarray.")
    new_traces = np.zeros((traces.shape[0], traces.shape[1]), dtype=float)
    # point_list = []
    for t in range(traces.shape[0]):
        for i in range(0, traces.shape[1]):
            if i == 0:
                new_traces[t][0] = traces[t][0]
            else:
                new_traces[t][i] = (a * traces[t][i - 1] + traces[t][i]) / (1 + a)
    return new_traces

if __name__ == '__main__':

    trace1 = np.load(r"D:/1224preprocessingTrace1Trace2.npy")
    trace12 = trace1[0:100]
    # 使用默认流
    trace12_device = cuda.to_device(trace12)
    new_traces = cuda.device_array((trace12.shape[0], trace12.shape[1]), dtype=np.float32)

    start = time()
    fast_lowpass[1, 100](trace12_device, 1, new_traces)
    gpu_result = new_traces.copy_to_host()
    cuda.synchronize()
    print("gpu time" + str(time() - start))

    start = time()

    # 使用5个stream
    number_of_streams = 5
    # 每个stream处理的数据量为原来的 1/5
    # 符号//得到一个整数结果
    segment_size = 20

    # 创建5个cuda stream
    stream_list = list()
    for i in range(0, number_of_streams):
        stream = cuda.stream()
        stream_list.append(stream)

    streams_out_device = cuda.device_array((segment_size, trace12.shape[1]), dtype=np.float32)
    streams_gpu_result = np.empty((trace12.shape[0], trace12.shape[1]), dtype=np.float32)

    # 启动多个stream
    for i in range(0, number_of_streams):
        # 传入不同的参数，让函数在不同的流执行
        x_i_device = cuda.to_device(trace12[i * segment_size: (i + 1) * segment_size], stream=stream_list[i])

        fast_lowpass[1, 20, stream_list[i]](x_i_device, 1, streams_out_device)

        streams_gpu_result[i * segment_size: (i + 1) * segment_size] = streams_out_device.copy_to_host(
            stream=stream_list[i])

    cuda.synchronize()
    print("gpu streams vector add time " + str(time() - start))

    start = time()
    fast_lowpass_cpu(trace12, 1)
    print("cpu time" + str(time() - start))

