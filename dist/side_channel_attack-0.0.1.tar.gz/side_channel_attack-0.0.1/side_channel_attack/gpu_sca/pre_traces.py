from scipy import signal
import numpy as np
from tqdm import trange
from numba import cuda

np.seterr(divide='ignore',invalid='ignore')
# import random
def moving_average(traces, window):
    # if not isinstance(traces, np.ndarray):
    #     raise TypeError("'data' should be a numpy ndarray.")
    new_traces = []
    for t in range(traces.shape[0]):
        list = []
        new_traces.append(list)
        for i in range(traces.shape[1] - window):
            sum = 0
            for j in range(i, i + window):
                sum = traces[t][j] + sum
            a = sum / window
            list.append(a)
    return np.array(new_traces)
def to_one(traces):
    if not isinstance(traces, np.ndarray):
        raise TypeError("'data' should be a numpy ndarray.")
    new_traces = np.zeros((traces.shape[0],traces.shape[1]), dtype=float)
    for t in trange(traces.shape[0]):
        a = np.mean(traces[t])
        # s = np.std(traces[t])
        new_traces[t] = (traces[t]-a)
    return new_traces
def fast_lowpass(traces,a):
    # if not isinstance(traces, np.ndarray):
    #     raise TypeError("'trace' should be a numpy ndarray.")
    new_traces = np.zeros((traces.shape[0],traces.shape[1]), dtype=float)
    # point_list = []
    for t in trange(traces.shape[0]):
        for i in range(0,traces.shape[1]):
            if i == 0:
                new_traces[t][0] = traces[t][0]
            else:
                new_traces[t][i] = (a*traces[t][i-1]+traces[t][i])/(1+a)
    return new_traces
def LowPass(trace, frequency, cutoff,  axis=-1, precision='float32'):
    if not isinstance(trace, np.ndarray):
        raise TypeError("'data' should be a numpy ndarray.")
    if not isinstance(frequency, int) and not isinstance(frequency, float):
        raise TypeError("'frequency' should be an of int or float type.")
    if frequency <= 0:
        raise ValueError("'frequency' should be positive.")
    b, a = signal.butter(3, 2 * cutoff / frequency, 'lowpass')  # 配置滤波器 8 表示滤波器的阶数
    filtedData = signal.filtfilt(b, a, trace)
    return filtedData
@cuda.jit
def fast_lowpass_wanggeyibu(traces, a, new_traces):
    t = cuda.threadIdx.x + cuda.blockIdx.x * cuda.blockDim.x
    gridStride = cuda.gridDim.x * cuda.blockDim.x
    for j in range(t, traces.shape[0], gridStride):
        for i in range(0, traces.shape[1]):
            if i == 0:
                new_traces[t][0] = traces[t][0]
            else:
                new_traces[t][i] = (a * traces[t][i - 1] + traces[t][i]) / (1 + a)
def moving_resamples(traces, k):
    if not isinstance(traces, np.ndarray):
        raise TypeError("'data' should be a numpy ndarray.")
    new_traces = np.zeros((traces.shape[0], traces.shape[1] // k), dtype=float)
    if k >= traces.shape[1]:
        raise ValueError('window is too bigooo!')
    n = traces.shape[1]
    for t in range(traces.shape[0]):
        list = []
        # //地板除
        for i in range(n // k):
            sum = 0
            for j in range(i * k, i * k + k):
                sum = traces[t][j] + sum
            a = sum / k
            list.append(a)
        new_traces[t] = np.array(list)
    return new_traces

if __name__ == '__main__':
    # 对曲线进行处理
    # trace = np.load(r"G:/pycharm/side_channel_attack/attack_method/traces/5000traces3000samples0presamplesWith0RandWithFixedIn1.npy")
    # trace = np.load(r"G:/pycharm/side_channel_attack/attack_method/traces/5000traces3000samples0presamplesWith0RandWithRandomIn1.npy")
    # trace = np.load(r"G:/pycharm/side_channel_attack/attack_method/traces/5000traces3000samples0presamplesWithRandomRandWithComputingIn1.npy")
    # trace = np.load(r"G:/pycharm/side_channel_attack/preprocessing/1224LateNighttrace1trace2.npy")
    # data = loadtxt(r"D:\usingPICO\data.csv",delimiter=',')
    for j in trange(40):
        arr = np.load(r"G:/pycharm/side_channel_attack/attack_method/1228traces/1228Traces3Traces4arrPart{0}.npy".format(j))
        tracetoone = moving_resamples(arr,5)
        tracepass = to_one(tracetoone)
        np.save('G:/pycharm/side_channel_attack/attack_method/1228traces/passarrPart{0}.npy'.format(j), tracepass)

    # 使用默认流
    # trace12_device = cuda.to_device(tracetoone)
    # new_traces = cuda.device_array((tracetoone.shape[0], tracetoone.shape[1]), dtype=np.float32)
    #
    # start = time()
    # fast_lowpass_wanggeyibu[1, 100](trace12_device, 10, new_traces)
    # gpu_result = new_traces.copy_to_host()
    # cuda.synchronize()
    # print("gpu time" + str(time() - start))
    # tracepass = fast_lowpass(tracetoone,0.5)
    # np.save('1224LateNight.npy',gpu_result)

    # plt.plot(t.T)
    # plt.show()




