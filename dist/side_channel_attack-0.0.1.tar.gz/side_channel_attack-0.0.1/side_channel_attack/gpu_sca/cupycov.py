import time

import cupy
import pandas as pd
# import cupy as np
import numpy as np
from cupyx.profiler import benchmark
def cov_func1(data, traces):
    if data.ndim == 1 and traces.ndim == 2:
        old_cov = np.zeros(traces.shape[1])
        old_mean_data = np.zeros(len(data))
        old_mean_traces = np.zeros(traces.shape[1])
        for i in range(traces.shape[0]):
            # 需要的均值
            new_mean_data = old_mean_data + (data[i] - old_mean_data) / (i + 1)
            new_mean_traces = old_mean_traces + (traces[i] - old_mean_traces) / (i + 1)
            # 注意这里的i值
            # 协方差的计算
            new_cov = (old_cov * i + (data[i] - old_mean_data[i]) * (traces[i] - new_mean_traces)) / (i + 1)
            old_mean_traces = new_mean_traces
            old_mean_data = new_mean_data
            old_cov = new_cov
        return new_cov
    else:
        print('please select proper style')

def cov_func1(data, traces):
    if data.ndim == 1 and traces.ndim == 2:
        old_cov = np.zeros(traces.shape[1])
        old_mean_data = 0
        old_mean_traces = np.zeros(traces.shape[1])
        for i in range(traces.shape[0]):
            # 需要的均值
            new_mean_data = np.add(old_mean_data,np.divide(np.subtract(data[i],old_mean_data) , np.add(i , 1)))
            new_mean_traces = np.add(old_mean_traces, np.divide(np.subtract(traces[i], old_mean_traces), np.add(i, 1)))
            # new_mean_traces = old_mean_traces + (traces[i] - old_mean_traces) / (i + 1)
            # 注意这里的i值
            # 协方差的计算
            new_cov = (old_cov * i + (data[i] - old_mean_data) * (traces[i] - new_mean_traces)) / (i + 1)
            old_mean_traces = new_mean_traces
            old_mean_data = new_mean_data
            old_cov = new_cov
        return new_cov
    else:
        print('please select proper style')
# CUPY_ACCELERATORS = cub python
# CUPY_ACCELERATORS=cub,cutensor python cupycov.py
@cupy.fuse()
def correlation_func(data, traces):
    if data.ndim == 1 and traces.ndim == 2:
        old_cov = np.zeros(traces.shape[1])
        old_mean_data = 0
        old_mean_traces = np.zeros(traces.shape[1])
        old_var_data = 0
        old_var_traces = np.zeros(traces.shape[1])
        for i in range(traces.shape[0]):
            new_mean_data = old_mean_data + (data[i] - old_mean_data) / (i + 1)
            new_mean_traces = old_mean_traces + (traces[i] - old_mean_traces) / (i + 1)
            new_var_data = old_var_data + ((data[i] - old_mean_data) * (data[i] - new_mean_data) - old_var_data) / (i + 1)
            new_var_traces = old_var_traces + ((traces[i] - old_mean_traces) * (traces[i] - new_mean_traces) - old_var_traces) / (i + 1)
            new_cov = (old_cov * i + (data[i] - old_mean_data) * (traces[i] - new_mean_traces)) / (i + 1)
            old_mean_data = new_mean_data
            old_mean_traces = new_mean_traces
            old_cov= new_cov
            old_var_traces = new_var_traces
            old_var_data= new_var_data
        # print(new_cov[i+1],new_var_traces[i + 1],new_var_data[i + 1])
        return new_cov / np.sqrt(new_var_traces * new_var_data)

    else:
        print('please select proper style')

def _hamming_weight(intermediate_value):
    '''

    :param intermediate_value: 一个中间值
    :return: 中间值的汉明重量
    '''
    m = 0
    while intermediate_value != 0:
        # print(type(intermediate_value))
        m=m+(intermediate_value & 1)
        intermediate_value >>= 1
    return m
def HW(data):
    '''

    :param data: 一组中间值
    :return: 一组中间值的汉明重量
    '''
    if not isinstance(data, np.ndarray):
        raise TypeError("'data' should be a numpy ndarray.")
    if data.ndim == 1:
        new_data = np.zeros(len(data), dtype=float)
        for i in range(len(data)):
            new_data[i] = _hamming_weight(int(data[i]))
        return new_data
    if data.ndim == 2:
        new_data = np.zeros((data.shape(0),data.shape[1]), dtype=float)
        for i in range(data.shape[0]):
            for j in range(data.shape[1]):
                new_data[i][j] = _hamming_weight(int(data[i][j]))
        return new_data

#
def calc_corr(a, b):
    a_avg = sum(a) / len(a)
    b_avg = sum(b) / len(b)

    # 计算分子，协方差————按照协方差公式，本来要除以n的，由于在相关系数中上下同时约去了n，于是可以不除以n
    cov_ab = sum([(x - a_avg) * (y - b_avg) for x, y in zip(a, b)])

    # 计算分母，方差乘积————方差本来也要除以n，在相关系数中上下同时约去了n，于是可以不除以n
    sq = np.sqrt(sum([(x - a_avg) ** 2 for x in a]) * sum([(x - b_avg) ** 2 for x in b]))

    corr_factor = cov_ab / sq

    return corr_factor
def one_key_guess(data, traces):
    one_key_guess_matrix = []
    for i in range(data.shape[1]):
        n = correlation_func(data[:, i], traces)
        one_key_guess_matrix.append(n)
    m = np.max(one_key_guess_matrix)
    t = np.where(one_key_guess_matrix == m)
    return t[0]
def get_imediate(label,klength):
    k_array = range(2**klength)
    data = np.zeros((label.shape[0],len(k_array)))
    for i in range(label.shape[0]):
        for j in range(len(k_array)):
            data[i][j] = int(label[i][0])^j
    return data
def hammingwhight(x: int, y: int) -> int:
    z = bin(x ^ y)[2:]
    count = 0
    for i in range(len(z)):
        if z[i] == '1':
            count += 1
    return count
if __name__ == '__main__':

    trace = np.load(r"/attack_method/traces/attack_traces_AES_HD.npy")
    label = np.load(r"/attack_method/traces/attack_labels_AES_HD.npy")
    # data = np.load(r"G:/pycharm/side_channel_attack/attack_method/traces/attack_ciphertext_AES_HD.npy")
    # label2 = label.reshape((25000,))

    # print(trace.shape,label.shape,data.shape)
    # print(data)
    # print(label[0][0])
    # def to_bin(data):
    #
    #     for i in range(data.shape[0]):
    #
    #         data[i][0] = bin(int(data[i][0]))[2:]
    #     return data
    # print(to_bin(label))
    # print(type(np.arange(10)))
    data = get_imediate(label,8)
    np.save("/attack_method/traces/label_data.npy", data)
    # print(label.shape,trace,label2)


