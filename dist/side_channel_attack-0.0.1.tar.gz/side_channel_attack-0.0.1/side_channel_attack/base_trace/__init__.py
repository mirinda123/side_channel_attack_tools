


# filepath = 'G:/py+idea/python/side_channel_attack/base_trace/exsample.csv'
# t1 = np.genfromtxt(filepath,delimiter=',',encoding='utf-8',skip_header=2)
# npt1 = t1[:,2]
# print(npt1)
# # print(t1)
from . import base
from . import data_resolve
from . import get_intermediate_value