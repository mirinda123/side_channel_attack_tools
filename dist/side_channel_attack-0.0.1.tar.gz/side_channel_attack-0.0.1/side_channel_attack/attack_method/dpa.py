import numpy as np

def dpa_attack(data, traces, subkey_num):
    '''

    :param data: intermediate value
    :param traces: traces
    :param subkey_num: subkey numbers
    :return:
    '''
    mean_diffs = np.zeros(255)
    key_guess = []
    for subkey in range(subkey_num):
        for kguess in range(data.shape[1]):
            one_list = []
            zero_list = []
            for i in range(traces.shape[0]):
                if (data[i] & 1):
                    one_list.append(traces[i])
                else:
                    zero_list.append(traces[i])
            one_avg = np.asarray(one_list).mean(axis=0)
            zero_avg = np.asarray(zero_list).mean(axis=0)
            mean_diffs[kguess] = np.max(abs(one_avg - zero_avg))
        guess = np.argsort(mean_diffs)[-1]
        key_guess.append(guess)
if __name__ == '__main__':
    pass
