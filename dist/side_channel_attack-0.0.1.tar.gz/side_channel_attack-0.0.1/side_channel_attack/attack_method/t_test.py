import numpy as np
from statistics_tools import var_func, mean_func
from matplotlib import pyplot as plt
from tqdm import tqdm, trange
def func(n,N):
    '''
    :param n: blocks of traces
    :param N: sample numbers
    :return: result
    '''
    count = 0
    old_var_even = np.zeros(N)
    old_mean_even = np.zeros(N)
    old_var_odd = np.zeros(N)
    old_mean_odd = np.zeros(N)
    oddcount = 0
    evencount = 0
    for j in trange(n):
        arr = np.load(r"G:/pycharm/side_channel_attack/attack_method/traces/modu_trace/arrPart{0}.npy".format(j))
        for i in range(arr.shape[0]):
            if count % 2 == 0:
                new_mean = old_mean_even + (arr[i] - old_mean_even) / (evencount + 1)
                new_var = old_var_even + ((arr[i] - old_mean_even) * (arr[i] - new_mean) - old_var_even) / (evencount + 1)
                old_mean_even = new_mean
                old_var_even = new_var
                evencount += 1
                count = count + 1
            else:
                new_mean = old_mean_odd + (arr[i] - old_mean_odd) / (oddcount + 1)
                new_var = old_var_odd + ((arr[i] - old_mean_odd) * (arr[i] - new_mean) - old_var_odd) / (oddcount + 1)
                old_mean_odd = new_mean
                old_var_odd = new_var
                oddcount += 1
                count = count + 1
    temp1 = old_mean_even-old_mean_odd
    temp2 = (old_var_even/evencount)+(old_var_odd/oddcount)
    test_result = temp1 / np.sqrt(temp2)
    return test_result

if __name__ == '__main__':
    print(func(1,330000))
    arr = np.load(r"/attack_method/traces/modu_trace/arrPart0.npy")
    print()

